/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.gestiondenominas;

import com.mycompany.gestiondenominas.laboral.DatosNoCorrectosException;
import com.mycompany.gestiondenominas.laboral.Empleado;
import com.mycompany.gestiondenominas.laboral.Nomina;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Clase principal que gestiona la lógica completa del sistema de nóminas.
 * 
 * Esta clase permite:
 * <ul>
 *   <li>Conectarse a una base de datos MariaDB</li>
 *   <li>Leer, modificar y guardar empleados</li>
 *   <li>Calcular y almacenar nóminas</li>
 *   <li>Realizar copias de seguridad en archivos de texto (.txt) y binarios (.dat)</li>
 *   <li>Manejar errores de conexión mediante un modo de respaldo basado en archivos</li>
 *   <li>Ofrecer un menú interactivo para operaciones comunes</li>
 * </ul>
 * 
 * @author aleja
 * @version 1.0
 */
public class CalculaNominasFusion {

    private static final String URL = "jdbc:mariadb://localhost:3306/gestion_nominas";
    private static final String USER = "root";
    private static final String PASSWORD = "123456";

    
    /**
     * Método principal que inicia la aplicación.
     *
     * Realiza las siguientes acciones:
     * <ol>
     *   <li>Conecta a la base de datos</li>
     *   <li>Carga empleados desde la BD</li>
     *   <li>Aplica modificaciones específicas (James Cosling y Ada Lovelace)</li>
     *   <li>Guarda cambios en la BD y en archivos de respaldo</li>
     *   <li>Muestra un menú interactivo</li>
     *   <li>Permite dar de alta nuevos empleados (manual o desde archivo)</li>
     * </ol>
     * 
     * @param args
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Connection con = null;
        try {

            //Conectar a la base de datos
            con = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Conexión a la base de datos establecida.");

            //Leer empleados desde la base de datos, debemos tener previamente la base de datos creada con los empleados dentro, para ello, proporciono un  .txt con las loneas de codigo para crear a traves del cmd la base de datos y sus empleados
            List<Empleado> empleados = leerEmpleadosDesdeBD(con);
            System.out.println("Empleados leidos desde la base de datos");

            //Modificaciones en memoria
            for (Empleado e : empleados) {
                if (e.getNombre().equals("James Cosling")) {
                    e.setCategoria(9);  // Actualizamos su categoría a 9
                    System.out.println("Categoría de " + e.getNombre() + " actualizada a 9.");
                } else if (e.getNombre().equals("Ada Lovelace")) {
                    e.incrAnyo();        // Incrementamos sus años trabajados en 1
                    System.out.println("Años trabajados de " + e.getNombre() + " incrementados");
                }
            }

            //Guardar los cambios en la Base de Datos
            guardarCambiosEnBD(con, empleados);
            System.out.println("Base de datos actualizada con los cambios.");

            //Guardar los sueldos en la tabla nominas
            guardarSueldosEnBD(con, empleados);
            System.out.println("Sueldos almacenados en la base de datos.");

            //Guardar los cambios en el archivo de texto, como es el inicio del programa el txt no exite
            File backup = new File("empleados.txt");
            if (!backup.exists()) {
                guardarEmpleadosEnArchivo(con, "empleados.txt"); // Solo primera vez
            }

            //Genera un archivo binario para guardar los suerdos como copia de seguridad
            escribirSalariosBinario(empleados);

            //Mostrar resultados por consola
            escribe(empleados);

            //Mostrar menu de opciones
            mostrarMenu(con, scanner);

            //Para dar de alta a un nuevo empleado de manera manual o a traves de un fichero de texto con empleados nuevos escritos en el
            System.out.print("Quieres meter un nuevo cliente(1) o una lista de clientes a traves del fichero de texto empleadosNuevos.txt(2): ");
            int valor = scanner.nextInt();
            if (valor == 1) {
                altaEmpleado(con);
            } else {
                altaEmpleado(con, "empleadosNuevos.txt");
            }

        } catch (SQLException e) {
            /*En caso de que de error al conectar con la base de datos, como no sabemos si el error puede ser por error de conexion o porque la base de datos esta vacia, llamaremos al metodo manejaProgramaConFichero
            *  que volvera a intentar conectar con la base de datos, si conecta con ella y detecta que la base de datos esta vacia, realizara los procesos deseados de actualizacion y guardado en el backup, en este caso en los ficheros .txt y .bat
             */
            System.err.println("Error de base de datos: " + e.getMessage());

            manejaProgramaConFichero();

        } catch (IOException e) {
            System.err.println("Error de E/S en los archivos: " + e.getMessage());
        } catch (DatosNoCorrectosException e) {
            System.err.println("Error en datos: " + e.getMessage());
        } finally {
            if (con != null) {
                try {
                    con.close();
                    System.out.println("Conexión cerrada.");
                } catch (SQLException e) {
                    System.err.println("Error al cerrar la base de datos: " + e.getMessage());
                }
            }
        }
    }

    /**
     * Lee todos los empleados almacenados en la tabla 'empleados' de la base de datos.
     * 
     * @param conn Conexión activa a la base de datos
     * @return Lista de objetos {@link Empleado} cargados desde la BD
     * @throws SQLException si ocurre un error en la consulta SQL
     * @throws DatosNoCorrectosException si los datos leídos no son válidos para crear un Empleado
     */
    
    private static List<Empleado> leerEmpleadosDesdeBD(Connection conn) throws SQLException, DatosNoCorrectosException {
        List<Empleado> empleados = new ArrayList<>();

        //Consulta SQL para obtener todos los campos de la tabla empleados
        String sql = "SELECT nombre, dni, sexo, categoria, anyos FROM empleados";
        
        try (PreparedStatement stmt = conn.prepareStatement(sql); ResultSet results = stmt.executeQuery()) {
            while (results.next()) {
                
                //Extraemos cada campo guardandolo en una variable
                String nombre = results.getString("nombre");
                String dni = results.getString("dni");
                char sexo = results.getString("sexo").charAt(0);
                int categoria = results.getInt("categoria");
                int anyos = results.getInt("anyos");

                //Creamos un nuevo objeto Empleado con los datos guardados previamente y lo añadimos a una lista la cual sera devuelta una vez completada
                Empleado emp = new Empleado(nombre, dni, sexo, categoria, anyos);
                empleados.add(emp);
                System.out.println("Empleado leído de BD: " + nombre);
            }
        }
        return empleados;  //Devolvemos la lista empleados completa
    }

    /**
     * Guardar cambios de empleados en la base de datos los campos "categoria" y "anyos"
     * Usa operaciones por lotes (batch) para mayor eficiencia.
     * 
     * @param conn Conexión activa a la base de datos
     * @param empleados Lista de empleados con los datos actualizados
     * @throws SQLException si ocurre un error en la actualización SQL
     */
    
    private static void guardarCambiosEnBD(Connection conn, List<Empleado> empleados) throws SQLException {

        //Sentencia SQL para actualizar la categoria y los años trabajados de un empleado usando su dni
        String sql = "UPDATE empleados SET categoria = ?, anyos = ? WHERE dni = ?";
        
        try (PreparedStatement preparedS = conn.prepareStatement(sql)) {
            for (Empleado e : empleados) {
                preparedS.setInt(1, e.getCategoria());
                preparedS.setInt(2, e.getAnyos());
                preparedS.setString(3, e.getDni());
                preparedS.addBatch(); // Para mayor eficiencia ya que mejora el rendimiento
            }
            int[] resultados = preparedS.executeBatch(); //Envia al servidor todo de una vez, con el executeUpdate seria muy lento si quisiese guardar muchos cambios de muchos clientes
            System.out.println(resultados.length + " empleados actualizados en la base de datos.");
        }
    }

    /**
     * Calcula y guarda los sueldos de los empleados en la tabla 'nominas'.
     * Si ya existe un registro para un empleado, lo actualiza (ON DUPLICATE KEY UPDATE).
     * 
     * @param conn Conexión activa a la base de datos
     * @param empleados Lista de empleados para los que se calcularán los sueldos
     * @throws SQLException si ocurre un error en las consultas SQL
     * @throws DatosNoCorrectosException si los datos del empleado son inválidos para el cálculo
     */
    
    private static void guardarSueldosEnBD(Connection conn, List<Empleado> empleados) throws SQLException, DatosNoCorrectosException {
        Nomina n = new Nomina();
        // Primero, obtenemos el id del empleado por DNI para relacionarlo en la tabla nominas e insertamos un nuevo registro en la nomina y tambien para no tener duplicados ponemos on duplicate key update y de esta manera actualizamos del empleado.
        String getIdSql = "SELECT id FROM empleados WHERE dni = ?";
        String upsertSql = "INSERT INTO nominas (empleado_id, sueldo) VALUES (?, ?)"
                + "ON DUPLICATE KEY UPDATE sueldo = VALUES(sueldo)";

        try (PreparedStatement getIdStmt = conn.prepareStatement(getIdSql); PreparedStatement upsertStmt = conn.prepareStatement(upsertSql)) {

            for (Empleado e : empleados) {
                double sueldo = n.sueldo(e);  //Calculamos el sueldo del empleado

                // Obtener id del empleado
                getIdStmt.setString(1, e.getDni());
                ResultSet rs = getIdStmt.executeQuery();
                if (rs.next()) {
                    int empleadoId = rs.getInt("id");

                    // Insertar sueldo
                    upsertStmt.setInt(1, empleadoId);
                    upsertStmt.setDouble(2, sueldo);
                    upsertStmt.executeUpdate();

                    System.out.printf("Sueldo de %.2f € guardado en BD para %s\n", sueldo, e.getNombre());
                }
            }
        }
    }
    
    /**
     * Guarda empleados en la base de datos.
     * Usa operaciones por lotes (batch) para mayor eficiencia.
     * 
     * @param conn Conexión activa a la base de datos
     * @param empleados Lista de empleados a insertar
     * @throws SQLException si ocurre un error en la inserción SQL
     * @throws DatosNoCorrectosException si los datos del empleado son inválidos
     */

    private static void guardarEmpleadosBD(Connection conn, List<Empleado> empleados) throws SQLException, DatosNoCorrectosException {
        String insertSql = "INSERT INTO empleados (nombre, dni, sexo, categoria, anyos) VALUES (?, ?, ?, ?, ?)";
        
        try (PreparedStatement insertStmt = conn.prepareStatement(insertSql)) {
            for (Empleado e : empleados) {
                insertStmt.setString(1, e.getNombre());
                insertStmt.setString(2, e.getDni());
                insertStmt.setString(3, String.valueOf(e.getSexo()));
                insertStmt.setInt(4, e.getCategoria());
                insertStmt.setInt(5, e.getAnyos());
                insertStmt.addBatch();

            }
            int[] resultados = insertStmt.executeBatch(); //Envia al servidor todo de una vez, con el executeUpdate seria muy lento si quisiese guardar muchos cambios de muchos clientes
            System.out.println(resultados.length + " empleados introducidos en la base de datos.");
        }
    }

    //AQUI EMPIEZAN LOS METODOS DE LECTURA Y ESCRITURA EN ARCHIVOS:
    
    /**
     * Da de alta un nuevo empleado mediante entrada por consola.
     * 
     * @param conn Conexión activa a la base de datos
     * @throws DatosNoCorrectosException si los datos introducidos son inválidos
     * @throws SQLException si ocurre un error en la base de datos
     * @throws IOException si ocurre un error al escribir en archivos
     */
    
    private static void altaEmpleado(Connection conn) throws DatosNoCorrectosException, SQLException, IOException {
        List<Empleado> empleado = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);

        System.out.print("Dime el nombre del empleado: ");
        String nombre = scanner.nextLine();

        System.out.print("Dime el dni del empleado: ");
        String dni = scanner.nextLine();

        System.out.print("Dime el sexo del empleado: ");
        char sexo = scanner.next().charAt(0);

        System.out.print("Dime a categoria del empleado: ");
        int categoria = scanner.nextInt();

        System.out.print("Dime los años del empleado: ");
        int anyos = scanner.nextInt();

        scanner.nextLine();  //Para limpiar el buffer
        
        Empleado emple = new Empleado(nombre, dni, sexo, categoria, anyos);
        empleado.add(emple);

        guardarEmpleadosBD(conn, empleado);
        guardarSueldosEnBD(conn, empleado);
        guardarEmpleadosEnArchivo(conn, "empleados.txt");

        //Para el .dat necesito todos los empleados, por lo que los leo de la base de datos
        List<Empleado> todosLosEmpleados = leerEmpleadosDesdeBD(conn);
        escribirSalariosBinario(todosLosEmpleados);
        escribe(empleado);

    }

    /**
     * Da de alta empleados leyendo desde un archivo de texto.
     * 
     * @param conn Conexión activa a la base de datos
     * @param archivoTexto Nombre del archivo de texto con empleados (formato: nombre,dni,sexo,categoria,anyos)
     * @throws IOException si el archivo no se puede leer
     * @throws DatosNoCorrectosException si los datos del archivo son inválidos
     * @throws SQLException si ocurre un error en la base de datos
     */
    
    private static void altaEmpleado(Connection conn, String archivoTexto) throws IOException, DatosNoCorrectosException, SQLException {
        List<Empleado> empleados;
        empleados = leerEmpleadosDesdeArchivo(archivoTexto);
        guardarEmpleadosBD(conn, empleados);
        guardarSueldosEnBD(conn, empleados);

        guardarEmpleadosEnArchivo(conn, "empleados.txt");

        List<Empleado> todosLosEmpleados = leerEmpleadosDesdeBD(conn);
        escribirSalariosBinario(todosLosEmpleados);
        escribe(empleados);
    }
    
    /**
     * Lee empleados desde un archivo de texto.
     * 
     * @param empleadosArchivo Ruta del archivo de texto
     * @return Lista de empleados leídos
     * @throws IOException si el archivo no existe o no se puede leer
     * @throws DatosNoCorrectosException si algún registro tiene datos inválidos
     */

    private static List<Empleado> leerEmpleadosDesdeArchivo(String empleadosArchivo) throws IOException, DatosNoCorrectosException {
        List<Empleado> empleados = new ArrayList<>();
        File archivoTexto = new File(empleadosArchivo);

        if (!archivoTexto.exists()) {
            throw new FileNotFoundException("Archivo " + empleadosArchivo + " no encontrado.");
        }

        try (BufferedReader br = new BufferedReader(new FileReader(archivoTexto))) {
            String linea;
            int lineaNum = 0;

            while ((linea = br.readLine()) != null) {
                lineaNum++;
                String[] partes = linea.split(",");
                //Dividimos la linea por las comas para obtener los campos y comprobamos que haya 5
                if (partes.length == 5) {
                    try {
                        String nombre = partes[0].trim();
                        String dni = partes[1].trim();
                        char sexo = partes[2].trim().charAt(0);  // Primer carácter del sexo
                        int categoria = Integer.parseInt(partes[3].trim());
                        int anosTrabajados = Integer.parseInt(partes[4].trim());

                        // Creamos un nuevo empleado y lo añadimos a la lista
                        Empleado emp = new Empleado(nombre, dni, sexo, categoria, anosTrabajados);
                        empleados.add(emp);

                        System.out.println("Empleado leído: " + nombre);

                    } catch (NumberFormatException ex) {
                        System.err.println("Error de conversión en línea " + lineaNum + ": " + linea);
                    } catch (DatosNoCorrectosException ex) {
                        System.err.println("Datos no válidos en línea " + lineaNum + ": " + ex.getMessage());
                    }
                } else {
                    System.err.println("Formato incorrecto en línea " + lineaNum + ": " + linea);
                }
            }
        }
        return empleados; // Devolvemos la lista completa de empleados

    }

    /**
     * Guarda todos los empleados de la base de datos en un archivo de texto.
     * Sobrescribe el archivo si ya existe.
     * 
     * @param con Conexión activa a la base de datos
     * @param empleadostxt Nombre del archivo de salida
     * @throws IOException si ocurre un error al escribir el archivo
     * @throws SQLException si ocurre un error al leer de la BD
     * @throws DatosNoCorrectosException si los datos leídos son inválidos
     */
    
    private static void guardarEmpleadosEnArchivo(Connection con, String empleadostxt) throws IOException, SQLException, DatosNoCorrectosException {
        List<Empleado> empleados = leerEmpleadosDesdeBD(con);
        try (PrintWriter pw = new PrintWriter(new FileWriter(empleadostxt))) {
            for (Empleado e : empleados) {
                // Escribimos en formato: nombre,dni,sexo,años,categoría
                pw.printf("%s,%s,%c,%d,%d%n",
                        e.getNombre(),
                        e.getDni(),
                        e.getSexo(),
                        e.getCategoria(),
                        e.getAnyos());
            }
        }
        System.out.println("Empleados guardados en: " + empleadostxt);
    }

  /**
     * Escribe los sueldos de los empleados en un archivo binario (sueldos.dat).
     * Formato: DNI (UTF) + sueldo (double).
     * 
     * @param empleados Lista de empleados cuyos sueldos se escribirán
     * @throws IOException si ocurre un error al escribir el archivo
     */  
    
    private static void escribirSalariosBinario(List<Empleado> empleados) throws IOException {
        try (DataOutputStream dos = new DataOutputStream(new FileOutputStream("sueldos.dat"))) {
            Nomina n = new Nomina();  // Instancia para calcular sueldos

            System.out.println("\nEscribiendo sueldos en archivo binario 'sueldos.dat'...");

            // Recorremos cada empleado
            for (Empleado e : empleados) {
                double sueldo = n.sueldo(e);  // Calculamos sueldo

                // Escribimos en el archivo binario:
                dos.writeUTF(e.getDni());     // DNI como cadena (UTF)
                dos.writeDouble(sueldo);      // Sueldo como número decimal (double)

                System.out.printf("  -> %s: %.2f €\n", e.getDni(), sueldo);
            }

            System.out.println("Archivo binario 'sueldos.dat' generado correctamente.");
        }
    }

    //EN CASO DE ERROR CON LA BASE DE DATOS. SE INTENTA NUEVAMENTE CONECTARSE Y SI LO LOGRA SE REALIZARA LO MISMO PERO COGIENDO LOS DATOS DESDE EL ARCHIVO DE TEXTO QUE ES NUESTRO BACKUP:
    private static void manejaProgramaConFichero() {
        Connection con;
        try {
            con = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Conexión a la base de datos establecida.");

            List<Empleado> empleados = leerEmpleadosDesdeArchivo("empleados.txt");

            //Modificaciones en memoria
            for (Empleado emp : empleados) {
                if (emp.getNombre().equals("James Cosling")) {
                    emp.setCategoria(9);  // Actualizamos su categoría a 9
                    System.out.println("Categoría de " + emp.getNombre() + " actualizada a 9.");
                } else if (emp.getNombre().equals("Ada Lovelace")) {
                    emp.incrAnyo();        // Incrementamos sus años trabajados en 1
                    System.out.println("Años trabajados de " + emp.getNombre() + " incrementados");
                }
            }

            //Guardar los cambios en la Base de Datos
            guardarCambiosEnBD(con, empleados);
            System.out.println("Base de datos actualizada con los cambios.");

            //Guardar los sueldos en la tabla nominas
            guardarSueldosEnBD(con, empleados);
            System.out.println("Sueldos almacenados en la base de datos.");

            //Genera copia de seguridad en el archivo de texto
            guardarEmpleadosEnArchivo(con, "empleados.txt");

            //Genera un archivo binario para guardar los suerdos como copia de seguridad
            escribirSalariosBinario(empleados);

            //Mostrar resultados por consola
            escribe(empleados);
        } catch (IOException | DatosNoCorrectosException ex) {
            System.err.println("Error: " + ex.getMessage());
        } catch (SQLException ex) {
            System.err.println("Error de base de datos, no conecto: " + ex.getMessage());
        }
    }

    /**
     * Muestra por consola la información de los empleados y sus sueldos calculados.
     * 
     * @param empleados Lista de empleados a mostrar
     */
    
    private static void escribe(List<Empleado> empleados) {
        Nomina n = new Nomina();
        System.out.println("\nEMPLEADOS Y SUS SUELDOS");
        for (Empleado e : empleados) {
            System.out.println(e);  // Imprime toString() del empleado
            System.out.printf("Sueldo calculado: %.2f €\n\n", n.sueldo(e));
        }
    }

    //MENU DE OPCIONES Y SUS METODOS DEL APARTADO 5:
    
    /**
     * Muestra un menú interactivo en consola para realizar operaciones sobre los empleados.
     * 
     * @param con Conexión activa a la base de datos
     * @param scanner Objeto para leer entrada del usuario
     */
    
    private static void mostrarMenu(Connection con, Scanner scanner) {
        boolean salir = false;
        while (!salir) {
            System.out.println("\n=== MENÚ DE GESTIÓN DE NÓMINAS ===");
            System.out.println("1. Mostrar información de todos los empleados");
            System.out.println("2. Mostrar salario de un empleado por DNI");
            System.out.println("3. Modificar datos de un empleado");
            System.out.println("4. Recalcular y actualizar salario de un empleado");
            System.out.println("5. Recalcular y actualizar salarios de todos los empleados");
            System.out.println("6. Realizar copia de seguridad en ficheros");
            System.out.println("0. Salir del menú");
            System.out.print("Elige una opción: ");

            int opcion;
            try {
                opcion = Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Opción inválida. Introduce un número.");
                continue; //Con continue saltamos el resto de la iteraccion actual del bucle y pasamos a la siguiente iteraccion, por lo que si salta la excepcion salta todo el bucle a una siguiente iteraccion. .
            }

            try {
                switch (opcion) {
                    case 1:
                        mostrarTodosEmpleados(con);
                        break;
                    case 2:
                        mostrarSalarioPorDNI(con, scanner);
                        break;
                    case 3:
                        modificarEmpleado(con, scanner);
                        break;
                    case 4:
                        recalcularSalarioEmpleado(con, scanner);
                        break;
                    case 5:
                        recalcularSalariosTodos(con);
                        break;
                    case 6:
                        realizarCopiaSeguridad(con);
                        break;
                    case 0:
                        salir = true;
                        System.out.println("Saliendo del menú...");
                        break;
                    default:
                        System.out.println("Opción no válida. Inténtalo de nuevo.");
                }
            } catch (SQLException | IOException | DatosNoCorrectosException e) {
                System.err.println("Error durante la operación: " + e.getMessage());
            }
        }
    }
    
    /**
     * Muestra la lista completa de empleados almacenados en la base de datos.
     * 
     * @param con Conexión activa a la base de datos
     * @throws SQLException si ocurre un error en la consulta
     * @throws DatosNoCorrectosException si los datos leídos son inválidos
     */

    private static void mostrarTodosEmpleados(Connection con) throws SQLException, DatosNoCorrectosException {
        List<Empleado> empleados = leerEmpleadosDesdeBD(con);
        if (empleados.isEmpty()) {
            System.out.println("No hay empleados en la base de datos.");
            return;
        }
        System.out.println("\n--- LISTA DE EMPLEADOS ---");
        for (Empleado e : empleados) {
            System.out.println(e);
        }
    }

    /**
     * Muestra el salario de un empleado dado su DNI.
     * Si no existe en la tabla "nominas", lo calcula dinámicamente.
     * 
     * @param con Conexión activa a la base de datos
     * @param scanner Objeto para leer el DNI del usuario
     * @throws SQLException si ocurre un error en la consulta
     * @throws DatosNoCorrectosException si los datos del empleado son inválidos
     */
    
    private static void mostrarSalarioPorDNI(Connection con, Scanner scanner) throws SQLException, DatosNoCorrectosException {
        System.out.print("Introduce el DNI del empleado: ");
        String dni = scanner.nextLine().trim();

        String sql = "SELECT e.nombre, e.dni, e.sexo, e.categoria, e.anyos, n.sueldo "
                + "FROM empleados e "
                + "LEFT JOIN nominas n ON e.id = n.empleado_id "
                + "WHERE e.dni = ?";
        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setString(1, dni);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                String nombre = rs.getString("nombre");
                double sueldo = rs.getDouble("sueldo");
                if (rs.wasNull()) {
                    Empleado emp = new Empleado(
                            nombre,
                            rs.getString("dni"),
                            rs.getString("sexo").charAt(0),
                            rs.getInt("categoria"),
                            rs.getInt("anyos")
                    );
                    sueldo = new Nomina().sueldo(emp);
                }
                System.out.printf("Empleado: %s\nDNI: %s\nSueldo: %.2f €\n", nombre, dni, sueldo);
            } else {
                System.out.println("Empleado con DNI " + dni + " no encontrado.");
            }
        }
    }

    /**
     * Permite modificar los datos de un empleado existente (nombre, sexo, categoría, años).
     * Solo se actualizan los campos que el usuario introduce.
     * 
     * @param con Conexión activa a la base de datos
     * @param scanner Objeto para leer la entrada del usuario
     * @throws SQLException si ocurre un error en la actualización
     * @throws DatosNoCorrectosException si se introducen datos inválidos
     */
    
    private static void modificarEmpleado(Connection con, Scanner scanner) throws SQLException, DatosNoCorrectosException {
        System.out.print("Introduce el DNI del empleado a modificar: ");
        String dni = scanner.nextLine().trim();

        String checkSql = "SELECT id FROM empleados WHERE dni = ?";
        try (PreparedStatement checkStmt = con.prepareStatement(checkSql)) {
            checkStmt.setString(1, dni);
            if (!checkStmt.executeQuery().next()) {
                System.out.println("Empleado con DNI " + dni + " no encontrado.");
                return;
            }
        }

        System.out.print("Nuevo nombre (deja en blanco para no cambiar): ");
        String nombre = scanner.nextLine().trim();
        System.out.print("Nuevo sexo (H/M, deja en blanco para no cambiar): ");
        String sexoStr = scanner.nextLine().trim();
        System.out.print("Nueva categoría (deja en blanco para no cambiar): ");
        String catStr = scanner.nextLine().trim();
        System.out.print("Nuevos años trabajados (deja en blanco para no cambiar): ");
        String anyosStr = scanner.nextLine().trim();

        StringBuilder update = new StringBuilder("UPDATE empleados SET ");
        List<Object> params = new ArrayList<>();
        boolean hayCambio = false;

        if (!nombre.isEmpty()) {
            update.append("nombre = ?, ");
            params.add(nombre);
            hayCambio = true;
        }
        if (!sexoStr.isEmpty()) {
            char sexo = sexoStr.toUpperCase().charAt(0);
            if (sexo != 'H' && sexo != 'M') {
                System.out.println("Sexo inválido. Debe ser H o M.");
                return;
            }
            update.append("sexo = ?, ");
            params.add(String.valueOf(sexo));
            hayCambio = true;
        }
        if (!catStr.isEmpty()) {
            try {
                int cat = Integer.parseInt(catStr);
                if (cat < 1 || cat > 10) {
                    System.out.println("Categoría debe estar entre 1 y 10.");
                    return;
                }
                update.append("categoria = ?, ");
                params.add(cat);
                hayCambio = true;
            } catch (NumberFormatException e) {
                System.out.println("Categoría inválida.");
                return;
            }
        }
        if (!anyosStr.isEmpty()) {
            try {
                int anyos = Integer.parseInt(anyosStr);
                if (anyos < 0) {
                    System.out.println("Años no pueden ser negativos.");
                    return;
                }
                update.append("anyos = ?, ");
                params.add(anyos);
                hayCambio = true;
            } catch (NumberFormatException e) {
                System.out.println("Años inválidos.");
                return;
            }
        }

        if (!hayCambio) {
            System.out.println("No se realizaron cambios.");
            return;
        }

        update.setLength(update.length() - 2); // quitar ", "
        update.append(" WHERE dni = ?");
        params.add(dni);

        try (PreparedStatement stmt = con.prepareStatement(update.toString())) {
            for (int i = 0; i < params.size(); i++) {
                stmt.setObject(i + 1, params.get(i));
            }
            int filas = stmt.executeUpdate();
            if (filas > 0) {
                System.out.println("Empleado actualizado correctamente.");
                recalcularSalarioPorDNI(con, dni);
            }
        }
    }

    /**
     * Recalcula y actualiza el salario de un empleado dado su DNI.
     * 
     * @param con Conexión activa a la base de datos
     * @param dni DNI del empleado
     * @throws SQLException si ocurre un error en la actualización
     * @throws DatosNoCorrectosException si los datos del empleado son inválidos
     */
    
    private static void recalcularSalarioPorDNI(Connection con, String dni) throws SQLException, DatosNoCorrectosException {
        String getIdSql = "SELECT id, nombre, categoria, anyos FROM empleados WHERE dni = ?";
        try (PreparedStatement getIdStmt = con.prepareStatement(getIdSql)) {
            getIdStmt.setString(1, dni);
            ResultSet rs = getIdStmt.executeQuery();
            if (rs.next()) {
                int id = rs.getInt("id");
                Empleado e = new Empleado(
                        rs.getString("nombre"),
                        dni,
                        'M',
                        rs.getInt("categoria"),
                        rs.getInt("anyos")
                );
                double sueldo = new Nomina().sueldo(e);

                String upsertSql = "INSERT INTO nominas (empleado_id, sueldo) VALUES (?, ?) "
                        + "ON DUPLICATE KEY UPDATE sueldo = ?";
                try (PreparedStatement upsertStmt = con.prepareStatement(upsertSql)) {
                    upsertStmt.setInt(1, id);
                    upsertStmt.setDouble(2, sueldo);
                    upsertStmt.setDouble(3, sueldo);
                    upsertStmt.executeUpdate();
                }
                System.out.printf("Sueldo recalculado y actualizado: %.2f €\n", sueldo);
            }
        }
    }

    /**
     * Solicita un DNI al usuario y recalcula el salario del empleado correspondiente.
     * 
     * @param con Conexión activa a la base de datos
     * @param scanner Objeto para leer el DNI
     * @throws SQLException si ocurre un error en la actualización
     * @throws DatosNoCorrectosException si los datos del empleado son inválidos
     */
    
    private static void recalcularSalarioEmpleado(Connection con, Scanner scanner) throws SQLException, DatosNoCorrectosException {
        System.out.print("Introduce el DNI del empleado: ");
        String dni = scanner.nextLine().trim();
        recalcularSalarioPorDNI(con, dni);
    }

     /**
     * Recalcula y actualiza los salarios de todos los empleados.
     * 
     * @param con Conexión activa a la base de datos
     * @throws SQLException si ocurre un error en la actualización
     * @throws DatosNoCorrectosException si los datos de algún empleado son inválidos
     */
    
    private static void recalcularSalariosTodos(Connection con) throws SQLException, DatosNoCorrectosException {
        List<Empleado> empleados = leerEmpleadosDesdeBD(con);
        guardarSueldosEnBD(con, empleados);
        System.out.println("Salarios de todos los empleados recalculados y actualizados.");
    }

    /**
     * Realiza una copia de seguridad completa:
     * <ul>
     *   <li>Sobrescribe empleados.txt con todos los empleados actuales</li>
     *   <li>Genera sueldos.dat con los sueldos calculados</li>
     * </ul>
     * 
     * @param con Conexión activa a la base de datos
     * @throws SQLException si ocurre un error al leer de la BD
     * @throws IOException si ocurre un error al escribir archivos
     * @throws DatosNoCorrectosException si los datos leídos son inválidos
     */

    private static void realizarCopiaSeguridad(Connection con) throws SQLException, IOException, DatosNoCorrectosException {
        List<Empleado> empleados = leerEmpleadosDesdeBD(con);
        // Sobrescribir archivo de texto
        try (PrintWriter pw = new PrintWriter(new FileWriter("empleados.txt"))) {
            for (Empleado e : empleados) {
                pw.printf("%s,%s,%c,%d,%d%n",
                        e.getNombre(),
                        e.getDni(),
                        e.getSexo(),
                        e.getCategoria(),
                        e.getAnyos());
            }
        }
        escribirSalariosBinario(empleados);
        System.out.println("Copia de seguridad realizada:");
        System.out.println("- empleados.txt (texto)");
        System.out.println("- sueldos.dat (binario)");
    }
}